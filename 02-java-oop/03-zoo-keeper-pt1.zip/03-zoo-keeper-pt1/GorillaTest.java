public class GorillaTest {
    public static void main(String[] args) {

    Gorilla tester=new Gorilla(100);
    tester.throwSomething();
    tester.throwSomething();
    tester.throwSomething();
    tester.eatBananas();
    tester.eatBananas();
    tester.climb();
    }
}