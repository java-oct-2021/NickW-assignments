public class BatTest {
    public static void main(String[] args) {
        Bat tester=new Bat(300);
        tester.attackTown();
        tester.attackTown();
        tester.attackTown();
        tester.eatHumans();
        tester.eatHumans();
        tester.fly();
        tester.fly();
    }
}
